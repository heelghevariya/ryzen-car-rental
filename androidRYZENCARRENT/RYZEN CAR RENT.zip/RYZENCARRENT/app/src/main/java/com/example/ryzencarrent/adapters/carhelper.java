package com.example.ryzencarrent.adapters;

public class carhelper {
    int image;
    public carhelper(int image) {
        this.image = image;
    }


    public int getImage() {
        return image;
    }

}
