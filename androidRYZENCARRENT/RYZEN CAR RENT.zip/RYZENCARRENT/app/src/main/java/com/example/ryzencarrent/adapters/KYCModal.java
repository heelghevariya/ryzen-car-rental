package com.example.ryzencarrent.adapters;

import com.google.gson.annotations.SerializedName;

public class KYCModal {


    @SerializedName("uid")
    private int uid;

    @SerializedName("mail")
    private String mail;

    @SerializedName("fname")
    private String fname;
    @SerializedName("ano")
    private String ano;
    @SerializedName("pno")
    private String pno;
    @SerializedName("lno")
    private String lno;
    @SerializedName("aimg1")
    private String aimg1;
    @SerializedName("aimg2")
    private String aimg2;
    @SerializedName("pimg")
    private String pimg;
    @SerializedName("limg1")
    private String limg1;
    @SerializedName("limg2")
    private String limg2;



}
