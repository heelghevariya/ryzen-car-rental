package com.example.ryzencarrent;

public class config {

//    public static String Email_signup_BASE_URL = "http://192.168.19.237:7882/api/";
//    public static String Email_Image_BASE_URL = "http://192.168.19.237:7882/carrental/img/vehicleimages/";

    public static String Email_signup_BASE_URL = "http://192.168.1.8/api/";
    public static String Email_Image_BASE_URL = "http://192.168.1.8/carrental/img/vehicleimages/";


}
