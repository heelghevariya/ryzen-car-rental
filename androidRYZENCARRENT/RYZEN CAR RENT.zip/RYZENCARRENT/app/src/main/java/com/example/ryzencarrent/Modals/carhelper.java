package com.example.ryzencarrent.Modals;

public class carhelper {
    int image;
    public carhelper(int image) {
        this.image = image;
    }


    public int getImage() {
        return image;
    }

}
