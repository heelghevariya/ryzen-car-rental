package com.example.ryzencarrent.drawermenu;

import static com.example.ryzencarrent.Constants.Verified_Email;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.example.ryzencarrent.EmailVerification;
import com.example.ryzencarrent.HomeScreen.HomeScreen;
import com.example.ryzencarrent.LoginScreen;
import com.example.ryzencarrent.R;
import com.example.ryzencarrent.SignUpActivity;
import com.example.ryzencarrent.adapters.AppPreferences;

import org.w3c.dom.Text;

public class EmailChangeConfirm extends AppCompatActivity {

    int id;
    PinView edtOtp;
    TextView btnsubmit;
    ImageView close_btn;
    ProgressDialog dialog;
AppPreferences appPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_change_confirm);
appPreferences=new AppPreferences(getApplicationContext());
        id = getIntent().getIntExtra("otp", 0);
        close_btn = (ImageView) findViewById(R.id.close);


        edtOtp = (PinView) findViewById(R.id.setpin);
        btnsubmit = (TextView) findViewById(R.id.search_btn);

        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage("Loading...");

        close_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String OtpCode = edtOtp.getText().toString();
                if (OtpCode.equals("")) {
                    Toast.makeText(EmailChangeConfirm.this, "Enter Otp", Toast.LENGTH_SHORT).show();
                } else {

//                    dialog.show();

                    if (id == Integer.parseInt(OtpCode)) {
                        appPreferences.saveemailpref(Verified_Email);
                        Toast.makeText(EmailChangeConfirm.this, "Email Updated Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(EmailChangeConfirm.this, HomeScreen.class);
//                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        finishAffinity();
                    } else {
                        Toast.makeText(EmailChangeConfirm.this, "You entered wrong otp!", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}