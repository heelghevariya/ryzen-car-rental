package com.example.ryzencarrent.adapters;

public class SliderItems {
    String image;

    public SliderItems(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
