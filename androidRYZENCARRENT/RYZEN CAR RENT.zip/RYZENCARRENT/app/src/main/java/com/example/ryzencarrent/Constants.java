package com.example.ryzencarrent;

public class Constants {

    public static String Verified_Email;
    public static String Forgot_Mail;
    public static String Const_FromDate;
    public static String Const_ToDate;


    public static String fname;
    public static String ano;
    public static String aimg1;
    public static String aimg2;

    public static String pno;
    public static String pimg;

    public static String lno;
    public static String limg1;
    public static String limg2;
}
