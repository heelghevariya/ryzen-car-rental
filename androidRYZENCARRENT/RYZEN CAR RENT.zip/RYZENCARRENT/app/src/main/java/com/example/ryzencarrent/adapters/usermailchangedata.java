package com.example.ryzencarrent.adapters;

public class usermailchangedata {
}
