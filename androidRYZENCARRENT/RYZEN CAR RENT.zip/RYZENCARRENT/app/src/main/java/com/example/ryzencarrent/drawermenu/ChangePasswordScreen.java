package com.example.ryzencarrent.drawermenu;

import static com.example.ryzencarrent.adapters.AppPreferences.APP_SHARED_PREFS;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ryzencarrent.LoginScreen;
import com.example.ryzencarrent.R;
import com.example.ryzencarrent.RetrofitAPI;
import com.example.ryzencarrent.adapters.AppPreferences;
import com.example.ryzencarrent.adapters.UpdatePassword;
import com.example.ryzencarrent.config;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ChangePasswordScreen extends AppCompatActivity {

    TextView changpassword;
    TextInputEditText currentpassword, newpassword, confirmpassword;
    AppPreferences appPreferences;
    UpdatePassword updatePassword;
ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password_screen);

        appPreferences = new AppPreferences(getApplicationContext());

        changpassword = findViewById(R.id.search_btn);
        currentpassword = findViewById(R.id.editcurrentpass);
        newpassword = findViewById(R.id.editpassword);
        confirmpassword = findViewById(R.id.editconfirmpass);
        back = findViewById(R.id.back);

        changpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (newpassword.getText().toString().equals(confirmpassword.getText().toString())) {
                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(config.Email_signup_BASE_URL)
                            // on below line we are calling add Converter
                            // factory as GSON converter factory.
                            .addConverterFactory(GsonConverterFactory.create())
                            // at last we are building our retrofit builder.
                            .build();
                    // below line is to create an instance for our retrofit api class.
                    RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);

                    Call<UpdatePassword> call = retrofitAPI.updatepassword(appPreferences.getuidpref(),
                            currentpassword.getText().toString(),
                            newpassword.getText().toString()

                    );
                    call.enqueue(new Callback<UpdatePassword>() {
                        @Override
                        public void onResponse(Call<UpdatePassword> call, Response<UpdatePassword> response) {
                            if (response.isSuccessful()) {


                                if (response.body() != null) {
                                    updatePassword = response.body();

                                    if (updatePassword.getStatus() == 1) {
                                        Toast.makeText(ChangePasswordScreen.this, "Password Updated.", Toast.LENGTH_SHORT).show();
                                        SharedPreferences _sharedPrefs;
                                        _sharedPrefs = getSharedPreferences(APP_SHARED_PREFS, Activity.MODE_PRIVATE);
                                        _sharedPrefs.edit().clear().commit();
                                        startActivity(new Intent(ChangePasswordScreen.this, LoginScreen.class));
                                        finish();
                                    }else {
                                        Toast.makeText(ChangePasswordScreen.this, "Invalid Password.", Toast.LENGTH_SHORT).show();

                                    }

                                }


                            }
                        }

                        @Override
                        public void onFailure(Call<UpdatePassword> call, Throwable t) {
                            // displaying an error message in toast
                            Toast.makeText(ChangePasswordScreen.this, "Fail to get the data..", Toast.LENGTH_SHORT).show();
                        }
                    });


                } else {
                    Toast.makeText(ChangePasswordScreen.this, "Confirm password must be same.", Toast.LENGTH_SHORT).show();
                }


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}