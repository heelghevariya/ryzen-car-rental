package com.example.ryzencarrent.adapters;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

public class phonehelper {
    int image;

    public phonehelper(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }
}
