package com.example.ryzencarrent.VisitorPanel;

import static com.example.ryzencarrent.Constants.Const_FromDate;
import static com.example.ryzencarrent.Constants.Const_ToDate;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ryzencarrent.HomeScreen.CarListScreen;
import com.example.ryzencarrent.HomeScreen.DateSelectionScreen;
import com.example.ryzencarrent.R;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Calendar;

public class VisiterDateSelection extends AppCompatActivity {

    TextInputEditText from, to;
    DatePickerDialog.OnDateSetListener onDateSetListener, onDateSetListener1;
    int year, Month, day;
    int year1, month1, day1;
    ImageView back_btn;
    TextView search_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visiter_date_selection);
        final Calendar calender = Calendar.getInstance();

        year1 = calender.get(Calendar.YEAR);
        month1 = calender.get(Calendar.MONTH);
        day1 = calender.get(Calendar.DAY_OF_MONTH);

        year = calender.get(Calendar.YEAR);
        Month = calender.get(Calendar.MONTH);
        day = calender.get(Calendar.DAY_OF_MONTH);

        back_btn = findViewById(R.id.back);
        search_btn = findViewById(R.id.search_btn);
        from = findViewById(R.id.fromdate);
        to = findViewById(R.id.todate);

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!from.getText().toString().equals("") && !to.getText().toString().equals("")) {
                    Const_FromDate = from.getText().toString();
                    Const_ToDate = to.getText().toString();
                    Intent intent = new Intent(VisiterDateSelection.this, VisitorCarList.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(VisiterDateSelection.this, "Select From-Date and To-Date.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        from.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        VisiterDateSelection.this, R.style.DatePickerTheme,
                        onDateSetListener, year, Month, day);

                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });

        to.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        VisiterDateSelection.this, R.style.DatePickerTheme,
                        onDateSetListener1, year1, month1, day1);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });


        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int month, int dayofmonth) {
                String nd = "" + dayofmonth;
                String nm = "" + month;
                if (dayofmonth < 10) {
                    nd = "0" + dayofmonth;
                }


                if ((month + 1) < 10) {
                    nm = "0" + (month + 1);
                } else {
                    nm = "" + (month + 1);
                }
                Log.d("testValue", String.valueOf(month));

                // for button text
                from.setText((year + "-" + nm + "-" + nd));
            }
        };

        onDateSetListener1 = new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year1, int month1, int dayofmonth1) {
                String nd = "" + dayofmonth1;
                String nm = "" + month1;
                if (dayofmonth1 < 10) {
                    nd = "0" + dayofmonth1;
                }


                if ((month1 + 1) < 10) {
                    nm = "0" + (month1 + 1);
                } else {
                    nm = "" + (month1 + 1);
                }
                Log.d("testValue", String.valueOf(month1));

                // for button text
                to.setText((year1 + "-" + nm + "-" + nd));
            }
        };
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}